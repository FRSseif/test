let greetings="Hello World"
displayThisText(greetings)