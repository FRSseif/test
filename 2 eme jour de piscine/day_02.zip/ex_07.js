if  (password === "forty-two") {
    displayThisText ("Success");
}
else {
    displayThisText ("Wrong password");
}