if ((breadCount >= 2) && hamCount >= 1 && (tunaCount >= 1)) {
    displayThisText("i can make a royal sandwich")
} else if ((breadCount >= 2) && (hamCount >= 1)) {
    displayThisText("i can make a ham sandwich")
} else if ((breadCount >= 2) && (tunaCount >= 1)) {
    displayThisText("i can make a tuna sandwich")
} else {
    displayThisText("I'd rather be fasting tonight..")
}