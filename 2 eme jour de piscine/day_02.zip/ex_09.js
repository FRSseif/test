if (input_var === "42"){
    displayThisText("The variable value is " + (input_var) + "."
        + "<br/>" + "It's type is " + (typeof input_var) + "<br/>" + "It is the meaning of life")
}
else {displayThisText("The variable value is " + (input_var) + "."
    + "<br/>" + "It's type is " + (typeof input_var) + ".")}