let integer= 42;
let string ="forty two";
let bool = 42.42;
let this_is_null = null;
displayThisText(integer)
displayThisText(string)
displayThisText(bool)
displayThisText(this_is_null)