if  (bananasCount>0){
    displayThisText ("Yummy!")
}
else if (bananasCount==0){
    displayThisText ("Oh no there is no banana.")
}
else {
    displayThisText ("Do i owe you bananas")
}