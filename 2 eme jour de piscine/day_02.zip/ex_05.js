let computedBankInfo = "John,Doe,1111 2222 3333 4444,21/2042"
displayInCard(computedBankInfo)