function switchToUppercase(arr) {
    return arr.map(word => word.toUpperCase());
}