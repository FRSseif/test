function getAngryDog(numberOfWoofs)
{
    let result = ""
    for(let i = 0; i < numberOfWoofs; i++) {
        result += "woof";
    }
    return result;
}