window.onload = function() {
    let tag = document.getElementById ('tag');
    tag.remove()
}
