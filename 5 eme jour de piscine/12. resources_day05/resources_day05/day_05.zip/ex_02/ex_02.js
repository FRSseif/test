window.onload = function() {
    let descriptionElement = document.getElementById ('description');
    descriptionElement.innerHTML = '0 <br/> 1 <br/> 2';
}