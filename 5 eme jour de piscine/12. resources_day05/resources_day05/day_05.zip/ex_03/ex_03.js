window.onload = function() {
    let descriptionElement = document.getElementById ('description');
    descriptionElement.innerHTML += "Now featuring a headphone jack!";
}