window.onload = function() {
    document.getElementById ("price").innerHTML = "0€"
}