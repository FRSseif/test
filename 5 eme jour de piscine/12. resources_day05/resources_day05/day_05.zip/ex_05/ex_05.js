window.onload = function () {
    document.getElementById("addToCart").addEventListener("click", function () {
    alert("Thanks!")});
};