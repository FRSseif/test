function calculator() {
    if (action === "add") {
        return addition();
    } else {
        return substraction();
    }
}

function addition() {
    return a + b;


}

function substraction() {
    return a - b;

}

