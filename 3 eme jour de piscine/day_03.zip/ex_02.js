function addTwo() {
    return number += 2
}