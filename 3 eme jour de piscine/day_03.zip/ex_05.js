function getBasketContent() {
    let arrayfruits = ["strawberry","strawberry","strawberry","apple","apple","lime","lime","peach","pear", "pear"]
    console.log(arrayfruits.length + "fruits selected")
    return arrayfruits
}