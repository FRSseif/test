function sayHi() {
    console.log("Hi !")
}